package com.viettridao.cafe.common;

public enum TableStatus {
    AVAILABLE, OCCUPIED, RESERVED, OUT_OF_SERVICE
    //Trống, Đang sử dụng, Đã đặt trước, Ngừng phục vụ
}
