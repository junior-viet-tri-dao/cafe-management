package com.viettridao.cafe.service;

public interface AuthService {
    boolean login(String username, String password);
}
