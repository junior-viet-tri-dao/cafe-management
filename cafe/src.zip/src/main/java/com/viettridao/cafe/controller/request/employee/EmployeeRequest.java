package com.viettridao.cafe.controller.request.employee;

public class EmployeeRequest {
}
